# LifeOS India Android V1

This project wraps the LifeOS HTML frontend with Capacitor.

## App ID
com.lifeosindia.app

## Build locally
npm install
npx cap add android
npx cap sync android

Then open Android Studio:
npx cap open android

## GitHub APK build
Push this project to GitHub. The workflow in:
.github/workflows/android.yml
will build a debug APK automatically.

After the workflow completes:
GitHub → Actions → Build LifeOS India APK → Artifacts → lifeos-india-debug-apk

## Important
This is a debug APK for testing. A Play Store release needs a signed release build and proper Android app configuration.
